#!/usr/bin/env bash
# Smoke test: backend unit/API tests, then the browser flow against live servers.
# Starts the API and the Vite dev server if they are not already running.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="${PYTHON:-python3}"

(cd "$ROOT/backend" && "$PY" -m pytest -q)

start_if_down() {  # $1 = url, $2.. = command
  local url="$1"; shift
  if ! curl -sf "$url" >/dev/null 2>&1; then
    ( "$@" >/tmp/flashpass_$$.log 2>&1 & echo $! >>/tmp/flashpass_pids_$$ )
    for _ in $(seq 1 30); do curl -sf "$url" >/dev/null 2>&1 && return 0; sleep 0.5; done
    echo "Could not start $url" >&2; exit 1
  fi
}
start_if_down http://127.0.0.1:8000/api/health bash -c "cd '$ROOT/backend' && exec $PY -m uvicorn app.main:app --port 8000"
start_if_down http://127.0.0.1:5173/ bash -c "cd '$ROOT/frontend' && exec npx vite --port 5173 --strictPort"

"$PY" -m pytest "$ROOT/playwright_tests" -q
echo "Smoke test passed."
