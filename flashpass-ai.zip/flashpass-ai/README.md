# FlashPass AI

A test-mode cinema-booking demo with a rule-based booking agent. Everything is fictional:
films, cinemas, prices and bookings. No payment is collected and no real ticketing service is contacted.

**Status: Phase 1 vertical slice (see "What is not built yet").**

## What works now

- Fictional catalogue of 4 films, 3 cinemas (configurable seat capacity), 3 dates and 4 showtimes.
- Seat map with available, unavailable, accessible and premium seats. Occupancy is seeded from the show id, so it is deterministic.
- Adjacent-seat selection and live pricing in the browser. The server re-checks every selection.
- Booking validation, then confirmation. Confirmation refuses to run unless `user_confirmed` is `true`.
  Double-booking is blocked by a unique constraint in SQLite.
- Rule-based agent: parses a request into hard constraints and soft preferences, asks for missing essentials,
  searches the schedule, selects seats, re-validates, and stops for review. It never books.
- Browser tests (Playwright, Chromium) covering the full flow, the agent stop-before-booking rule, and the clarification path.

## Run it

```bash
# Backend (Python 3.12+)
cd backend && pip install -r requirements.txt
python -m uvicorn app.main:app --port 8000

# Frontend (Node 18+), in another terminal
cd frontend && npm install && npm run dev        # http://localhost:5173
```

Smoke test (backend tests, then browser tests, starting servers if needed):

```bash
bash scripts/run_smoke.sh
```

Browser tests need Playwright's Chromium: `python -m playwright install chromium`.

## Try the agent

Open `http://localhost:5173/agent`. Good examples:

- "Book 2 adjacent seats for Neon Harbor at 7 PM, total below ₹800": produces a plan and waits for review.
- "Book two adjacent seats for the 7 PM show, below ₹800": asks which movie. The spec's example omits the movie, so the agent asks rather than guessing.
- "Book 4 seats for Ghost Circuit at 3 AM": explains there is no such show and suggests alternatives.

## API

| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | Status and booking count |
| GET | `/api/movies`, `/api/cinemas` | Catalogue |
| GET | `/api/shows?movie_id&cinema_id&date` | Filtered showtimes with seat counts |
| GET | `/api/seats?show_id` | Full seat map with status and price |
| POST | `/api/booking/validate` | Read-only check |
| POST | `/api/booking/confirm` | Needs `"user_confirmed": true`; returns 201, 400 or 409 |
| GET | `/api/booking/{reference}` | Look up a stored booking |
| POST | `/api/agent/plan` | Parse, search and plan. Never books. |
| POST | `/api/agent/run` | Currently same as plan. `browser_executed` is always `false`. |

## Tests

- `backend/tests`: 30 pytest tests covering parsing, seat logic, budget strictness, validation, the confirmation gate, API errors and planner behaviour.
- `playwright_tests`: 6 browser tests against the live servers.

## What is not built yet

- Playwright-driven agent that navigates the site (the baseline, DOM-aware and hybrid modes).
- Interface-drift injection and the seeded fault-injection control panel.
- FlashPass-Bench dataset generator, schema validation, and JSON/CSV exports.
- Benchmark runner, metrics, charts and the research dashboard.
- Optional LLM parser or vision fallback.
- The `docs/` set (methodology, metrics, limitations, six-month plan).

Until those exist, no experimental results or performance claims are made.

## Known limitations

- The display font (Fraunces) is loaded from Google Fonts. Without network access it falls back to a system serif.
- The rule-based parser handles common phrasings only. Unusual wording may need a clarification round.
- Seat selection in the UI is a client-side convenience. The server's validation is authoritative.
- The database file at `backend/data/flashpass.db` persists between runs. Delete it to reset.
