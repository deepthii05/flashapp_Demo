/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        night: "#0b1020",
        panel: "#131c36",
        line: "#2a3766",
        mist: "#aab5d9",
        paper: "#eef1ff",
        violet: { DEFAULT: "#9b8cff", deep: "#6d5bf0" },
        cyan: { DEFAULT: "#4fdcf5" },
        caution: "#f5c15c",
        danger: "#ff8a9a",
      },
      fontFamily: {
        display: ['"Fraunces"', "Georgia", "serif"],
        body: ['"Manrope"', "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
