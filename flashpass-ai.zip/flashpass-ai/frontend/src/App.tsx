import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import Agent from "./pages/Agent";
import Confirmation from "./pages/Confirmation";
import Home from "./pages/Home";
import MovieDetail from "./pages/MovieDetail";
import Review from "./pages/Review";
import Seats from "./pages/Seats";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/movies/:movieId" element={<MovieDetail />} />
        <Route path="/book/:showId" element={<Seats />} />
        <Route path="/review" element={<Review />} />
        <Route path="/confirmation/:reference" element={<Confirmation />} />
        <Route path="/agent" element={<Agent />} />
        <Route path="*" element={<p className="text-mist">Page not found.</p>} />
      </Route>
    </Routes>
  );
}
