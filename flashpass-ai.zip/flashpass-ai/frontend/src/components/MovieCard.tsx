import { Link } from "react-router-dom";
import type { Movie } from "../types";

// Locally generated placeholder artwork: no real posters are used.
const ART: Record<string, string> = {
  "neon-harbor": "from-cyan/50 via-[#1d2a5c] to-night",
  "monsoon-train": "from-caution/40 via-[#2a2353] to-night",
  "ghost-circuit": "from-violet/60 via-[#1b1f44] to-night",
  "saffron-skies": "from-[#f08a5d]/50 via-[#262049] to-night",
};

export default function MovieCard({ movie }: { movie: Movie }) {
  return (
    <Link
      to={`/movies/${movie.id}`}
      className="group block rounded-md border border-line bg-panel overflow-hidden hover:border-cyan/60 focus-visible:outline-cyan"
    >
      <div className={`relative aspect-[3/4] bg-gradient-to-b ${ART[movie.id] ?? "from-violet/40 to-night"} p-4 flex flex-col justify-end`}>
        <span className="absolute top-3 left-3 rounded bg-night/70 px-2 py-0.5 text-xs font-bold">{movie.rating}</span>
        <h3 className="font-display text-2xl leading-tight">{movie.title}</h3>
      </div>
      <div className="p-4 space-y-1">
        <p className="text-sm text-mist">
          {movie.genre} · {movie.duration_min} min
        </p>
        <p className="text-sm">{movie.show_count} showtimes, 1–3 Nov</p>
      </div>
    </Link>
  );
}
