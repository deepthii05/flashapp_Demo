import type { Seat } from "../types";

interface Props {
  rows: string[];
  seatsPerRow: number;
  seats: Seat[];
  selected: Set<string>;
  onToggle: (id: string) => void;
  disabled?: boolean;
}

export default function SeatGrid({ rows, seatsPerRow, seats, selected, onToggle, disabled }: Props) {
  const byId = new Map(seats.map((s) => [s.id, s]));
  return (
    <div className="overflow-x-auto pb-2">
      <div className="mx-auto w-max">
        <div className="mx-auto mb-6 h-2 w-3/4 rounded-full bg-gradient-to-r from-transparent via-violet/70 to-transparent" aria-hidden="true" />
        <p className="mb-4 text-center text-xs uppercase tracking-[0.2em] text-mist">Screen</p>
        <div role="group" aria-label="Seat map" className="grid gap-2" style={{ gridTemplateColumns: `auto repeat(${seatsPerRow}, minmax(0, 1fr))` }}>
          {rows.map((row) => (
            <div key={row} className="contents">
              <span className="flex items-center pr-2 text-xs text-mist" aria-hidden="true">{row}</span>
              {Array.from({ length: seatsPerRow }, (_, i) => {
                const id = `${row}${i + 1}`;
                const seat = byId.get(id);
                if (!seat) return <span key={id} />;
                const isSelected = selected.has(id);
                const unavailable = seat.status === "unavailable";
                const isDisabled = unavailable || disabled;
                let style = "border-line bg-transparent hover:border-cyan";
                if (unavailable) style = "border-line bg-[repeating-linear-gradient(45deg,#1a2344,#1a2344_3px,#131c36_3px,#131c36_6px)] opacity-60";
                if (isSelected) style = "border-violet bg-violet text-night";
                else if (seat.accessible && !unavailable) style = "border-cyan bg-cyan/10 hover:bg-cyan/20";
                const label = `Seat ${id}, ${seat.price} rupees${seat.accessible ? ", accessible" : ""}${unavailable ? ", unavailable" : ""}${isSelected ? ", selected" : ""}`;
                return (
                  <button
                    key={id}
                    type="button"
                    aria-label={label}
                    aria-pressed={isSelected}
                    disabled={isDisabled}
                    onClick={() => onToggle(id)}
                    className={`h-8 w-8 sm:h-9 sm:w-9 rounded-t-lg rounded-b-sm border text-[10px] font-bold transition-colors disabled:cursor-not-allowed ${style}`}
                  >
                    {seat.accessible ? "♿" : ""}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-4 justify-center text-xs text-mist">
          <Legend swatch="border border-line" label="Available" />
          <Legend swatch="bg-violet" label="Selected" />
          <Legend swatch="border border-cyan bg-cyan/10" label="Accessible" />
          <Legend swatch="bg-[repeating-linear-gradient(45deg,#1a2344,#1a2344_3px,#131c36_3px,#131c36_6px)]" label="Unavailable" />
        </div>
      </div>
    </div>
  );
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <span className="flex items-center gap-2">
      <span className={`inline-block h-4 w-4 rounded-sm ${swatch}`} aria-hidden="true" />
      {label}
    </span>
  );
}
