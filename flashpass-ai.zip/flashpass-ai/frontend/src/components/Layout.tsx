import { useEffect, useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { api } from "../services/api";

type AgentStatus = "checking" | "online" | "offline";

export default function Layout() {
  const [status, setStatus] = useState<AgentStatus>("checking");

  useEffect(() => {
    api
      .health()
      .then(() => setStatus("online"))
      .catch(() => setStatus("offline"));
  }, []);

  const statusText = { checking: "Checking agent", online: "Agent ready", offline: "Backend offline" }[status];
  const dot = { checking: "bg-mist", online: "bg-cyan", offline: "bg-danger" }[status];

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-line/70 bg-night/80 backdrop-blur sticky top-0 z-20">
        <div className="mx-auto max-w-6xl px-4 py-3 flex flex-wrap items-center gap-4 justify-between">
          <Link to="/" className="flex items-baseline gap-3 group">
            <span className="font-display text-2xl font-bold tracking-tight">FlashPass<span className="text-cyan"> AI</span></span>
            <span className="hidden sm:inline text-sm text-mist">Your booking, intelligently handled.</span>
          </Link>
          <nav className="flex items-center gap-5 text-sm font-semibold" aria-label="Main">
            <NavLink to="/" end className={({ isActive }) => (isActive ? "text-paper" : "text-mist hover:text-paper")}>Movies</NavLink>
            <NavLink to="/agent" className={({ isActive }) => (isActive ? "text-paper" : "text-mist hover:text-paper")}>AI booking</NavLink>
            <span className="flex items-center gap-2 text-mist" role="status" aria-live="polite">
              <span className={`inline-block h-2 w-2 rounded-full ${dot}`} aria-hidden="true" />
              {statusText}
            </span>
            <span className="rounded border border-caution/60 px-2 py-0.5 text-xs font-bold tracking-wide text-caution">TEST MODE</span>
          </nav>
        </div>
      </header>
      <main className="flex-1 mx-auto w-full max-w-6xl px-4 py-8">
        <Outlet />
      </main>
      <footer className="border-t border-line/70 text-sm text-mist">
        <div className="mx-auto max-w-6xl px-4 py-5">
          Fictional cinemas, films and prices. No payment is collected and no real ticketing service is contacted.
        </div>
      </footer>
    </div>
  );
}
