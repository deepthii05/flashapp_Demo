import { useEffect, useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { api, rupees } from "../services/api";
import type { Constraints, ReviewState, SeatMap, ValidationResult } from "../types";

export default function Review() {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as ReviewState | null;
  const [map, setMap] = useState<SeatMap | null>(null);
  const [check, setCheck] = useState<ValidationResult | null>(null);
  const [agreed, setAgreed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const constraints: Constraints = state?.constraints ?? {};

  useEffect(() => {
    if (!state) return;
    api.seats(state.showId).then(setMap).catch((e: Error) => setError(e.message));
    api.validate({ show_id: state.showId, seat_ids: state.seats, ...constraints })
      .then(setCheck)
      .catch((e: Error) => setError(e.message));
    // constraints is derived from state, so keying on state is enough here.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state?.showId]);

  if (!state) return <Navigate to="/" replace />;

  const seatPrices = check?.seat_prices ?? {};
  const total = check?.total ?? 0;

  async function confirmBooking() {
    if (!state || !agreed || !check?.valid) return;
    setBusy(true);
    setError(null);
    try {
      // The user clicked this button after reviewing the details above. This is the only
      // place user_confirmed is set to true.
      const receipt = await api.confirm({ show_id: state.showId, seat_ids: state.seats, user_confirmed: true, ...constraints });
      navigate(`/confirmation/${receipt.reference}`);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_360px]">
      <section className="space-y-6" aria-labelledby="review-heading">
        <div>
          <Link to={map ? `/book/${state.showId}` : "/"} className="text-sm text-mist hover:text-paper">← Change seats</Link>
          <h1 id="review-heading" className="mt-2 font-display text-4xl">Review your booking</h1>
        </div>

        {map && (
          <dl className="grid gap-4 rounded-md border border-line bg-panel p-5 sm:grid-cols-2">
            <Detail label="Film" value={map.movie_title} />
            <Detail label="Cinema" value={map.cinema_name} />
            <Detail label="Date" value={map.date} />
            <Detail label="Showtime" value={map.time} />
            <Detail label="Seats" value={state.seats.join(", ")} />
            <Detail label="Total" value={rupees(total)} />
          </dl>
        )}

        {constraints.max_total != null && (
          <p className="text-sm text-mist">
            Your limit: total {constraints.budget_strict ? "below" : "up to"} {rupees(constraints.max_total)}.
          </p>
        )}

        {check && !check.valid && (
          <div role="alert" className="rounded-md border border-danger/50 bg-danger/5 p-4 text-danger">
            <p className="font-bold">This booking can't be confirmed as it stands.</p>
            <ul className="mt-2 list-disc pl-5 text-sm">
              {check.errors.map((e) => <li key={e.code}>{e.message}</li>)}
            </ul>
          </div>
        )}
        {error && <p role="alert" className="text-danger">{error}</p>}

        <label className="flex items-start gap-3 rounded-md border border-line p-4">
          <input
            type="checkbox"
            className="mt-1 h-4 w-4 accent-violet"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
          />
          <span>I have checked these details. I want to create this test-mode booking.</span>
        </label>
      </section>

      <aside className="h-fit space-y-4 rounded-md border border-line bg-panel p-5 lg:sticky lg:top-24">
        <h2 className="font-display text-2xl">Seat prices</h2>
        <ul className="space-y-1 text-sm">
          {state.seats.map((s) => (
            <li key={s} className="flex justify-between">
              <span>Seat {s}</span>
              <span>{seatPrices[s] != null ? rupees(seatPrices[s]) : "—"}</span>
            </li>
          ))}
        </ul>
        <button
          type="button"
          onClick={confirmBooking}
          disabled={!agreed || !check?.valid || busy}
          className="w-full rounded-md bg-violet px-4 py-3 font-bold text-night disabled:opacity-40"
        >
          {busy ? "Creating booking…" : "Confirm test booking"}
        </button>
        <p className="text-xs text-mist">Fictional event. No payment is collected.</p>
      </aside>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wider text-mist">{label}</dt>
      <dd className="mt-1 font-bold">{value}</dd>
    </div>
  );
}
