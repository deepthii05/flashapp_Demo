import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, rupees } from "../services/api";
import type { Movie, ShowSummary } from "../types";

export default function MovieDetail() {
  const { movieId = "" } = useParams();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [shows, setShows] = useState<ShowSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [date, setDate] = useState<string | null>(null);

  useEffect(() => {
    api.movies().then((ms) => setMovie(ms.find((m) => m.id === movieId) ?? null)).catch((e: Error) => setError(e.message));
    api.shows({ movie_id: movieId }).then(setShows).catch((e: Error) => setError(e.message));
  }, [movieId]);

  const dates = useMemo(() => [...new Set((shows ?? []).map((s) => s.date))].sort(), [shows]);
  const activeDate = date ?? dates[0] ?? null;
  const byCinema = useMemo(() => {
    const map = new Map<string, ShowSummary[]>();
    (shows ?? []).filter((s) => s.date === activeDate).forEach((s) => {
      map.set(s.cinema_name, [...(map.get(s.cinema_name) ?? []), s]);
    });
    return [...map.entries()];
  }, [shows, activeDate]);

  if (error) return <p role="alert" className="text-danger">{error}</p>;
  if (!movie || !shows) return <p className="text-mist">Loading…</p>;

  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.4fr]">
      <article className="space-y-4">
        <Link to="/" className="text-sm text-mist hover:text-paper">← All films</Link>
        <h1 className="font-display text-5xl leading-tight">{movie.title}</h1>
        <p className="text-mist">{movie.genre} · {movie.duration_min} min · {movie.rating}</p>
        <p className="text-lg leading-relaxed">{movie.synopsis}</p>
        <p className="text-sm text-mist">Fictional film. Prices shown are fictional.</p>
      </article>

      <section aria-labelledby="showtimes" className="space-y-6">
        <h2 id="showtimes" className="font-display text-2xl">Choose a showtime</h2>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Date">
          {dates.map((d) => (
            <button
              key={d}
              type="button"
              aria-pressed={d === activeDate}
              onClick={() => setDate(d)}
              className={`rounded-md border px-3 py-2 text-sm ${d === activeDate ? "border-cyan text-cyan" : "border-line text-mist hover:text-paper"}`}
            >
              {new Date(d + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })}
            </button>
          ))}
        </div>
        {byCinema.map(([cinema, list]) => (
          <div key={cinema} className="rounded-md border border-line bg-panel p-4">
            <h3 className="font-bold">{cinema}</h3>
            <ul className="mt-3 flex flex-wrap gap-2">
              {list.map((s) => (
                <li key={s.show_id}>
                  <Link
                    to={`/book/${encodeURIComponent(s.show_id)}`}
                    className="block rounded-md border border-line px-3 py-2 hover:border-cyan focus-visible:outline-cyan"
                    aria-label={`${s.time} at ${s.cinema_name}, ${s.available_seats} seats left, from ${rupees(s.from_price)}`}
                  >
                    <span className="font-bold">{s.time}</span>
                    <span className="block text-xs text-mist">{s.available_seats} seats left · from {rupees(s.from_price)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </section>
    </div>
  );
}
