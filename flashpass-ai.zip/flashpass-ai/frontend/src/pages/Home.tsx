import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import MovieCard from "../components/MovieCard";
import { api } from "../services/api";
import type { Movie } from "../types";

export default function Home() {
  const [movies, setMovies] = useState<Movie[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("All");

  useEffect(() => {
    api.movies().then(setMovies).catch((e: Error) => setError(e.message));
  }, []);

  const genres = useMemo(() => ["All", ...new Set((movies ?? []).map((m) => m.genre))], [movies]);
  const visible = (movies ?? []).filter(
    (m) =>
      (genre === "All" || m.genre === genre) &&
      (!query || `${m.title} ${m.genre}`.toLowerCase().includes(query.toLowerCase())),
  );

  return (
    <div className="space-y-12">
      <section className="grid gap-8 md:grid-cols-[1.2fr_1fr] md:items-end">
        <div className="space-y-5">
          <h1 className="font-display text-5xl sm:text-6xl leading-[1.02] tracking-tight">
            Your booking, intelligently handled.
          </h1>
          <p className="max-w-xl text-mist text-lg">
            Pick a film, or describe what you want and let the agent find seats that fit your limits.
            It always stops for your confirmation before booking.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link to="/agent" className="rounded-md bg-violet px-5 py-3 font-bold text-night hover:bg-violet/90">
              Try AI Booking
            </Link>
            <a href="#movies" className="rounded-md border border-line px-5 py-3 font-bold hover:border-cyan">
              Browse films
            </a>
          </div>
        </div>
        <SeatMotif />
      </section>

      <section id="movies" aria-labelledby="movies-heading" className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <h2 id="movies-heading" className="font-display text-3xl">Now showing</h2>
          <div className="flex flex-wrap items-center gap-3">
            <label className="sr-only" htmlFor="search">Search films</label>
            <input
              id="search"
              type="search"
              placeholder="Search films"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="rounded-md border border-line bg-panel px-3 py-2 text-sm placeholder:text-mist/70 focus:border-cyan focus:outline-none"
            />
            <div className="flex gap-2" role="group" aria-label="Filter by genre">
              {genres.map((g) => (
                <button
                  key={g}
                  type="button"
                  aria-pressed={genre === g}
                  onClick={() => setGenre(g)}
                  className={`rounded-full border px-3 py-1 text-sm ${genre === g ? "border-cyan text-cyan" : "border-line text-mist hover:text-paper"}`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>
        </div>

        {error && <p role="alert" className="rounded-md border border-danger/50 p-4 text-danger">Could not load films: {error}</p>}
        {!movies && !error && <p className="text-mist">Loading films…</p>}
        {movies && visible.length === 0 && <p className="text-mist">No films match that search.</p>}
        <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-4">
          {visible.map((m) => (
            <MovieCard key={m.id} movie={m} />
          ))}
        </div>
      </section>
    </div>
  );
}

/** A small seat row where two adjacent seats are highlighted, showing what the agent looks for. */
function SeatMotif() {
  const cells = Array.from({ length: 12 }, (_, i) => i);
  return (
    <figure className="rounded-md border border-line bg-panel p-6" aria-label="Illustration of two adjacent seats being selected">
      <div className="grid grid-cols-12 gap-1.5">
        {cells.map((i) => {
          const taken = [1, 2, 5, 8, 9].includes(i);
          const picked = i === 6 || i === 7;
          const cls = picked ? "bg-violet border-violet" : taken ? "bg-line/60 border-transparent" : "border-cyan/60";
          return <span key={i} className={`h-5 rounded-t-md rounded-b-sm border ${cls}`} />;
        })}
      </div>
      <figcaption className="mt-4 text-sm text-mist">
        Two adjacent seats in one row, the constraint the agent checks first.
      </figcaption>
    </figure>
  );
}
