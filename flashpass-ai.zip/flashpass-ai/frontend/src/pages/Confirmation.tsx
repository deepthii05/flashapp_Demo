import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, rupees } from "../services/api";
import type { Receipt } from "../types";

export default function Confirmation() {
  const { reference = "" } = useParams();
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.booking(reference).then(setReceipt).catch((e: Error) => setError(e.message));
  }, [reference]);

  if (error) return <p role="alert" className="text-danger">{error}</p>;
  if (!receipt) return <p className="text-mist">Loading booking…</p>;

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <p className="rounded border border-caution/60 px-3 py-2 text-sm text-caution">
        TEST MODE. This is a fictional booking. No payment was collected.
      </p>
      {/* Ticket stub: the perforation is the only decoration, and it marks where the stub tears. */}
      <article aria-labelledby="ticket" className="relative rounded-md border border-line bg-panel">
        <div className="p-6 space-y-4">
          <h1 id="ticket" className="font-display text-3xl">Booked</h1>
          <p className="text-mist">{receipt.movie_title} · {receipt.cinema_name}</p>
          <dl className="grid grid-cols-2 gap-4">
            <div><dt className="text-xs uppercase tracking-wider text-mist">Date</dt><dd className="font-bold">{receipt.date}</dd></div>
            <div><dt className="text-xs uppercase tracking-wider text-mist">Showtime</dt><dd className="font-bold">{receipt.time}</dd></div>
            <div><dt className="text-xs uppercase tracking-wider text-mist">Seats</dt><dd className="font-bold">{receipt.seats.join(", ")}</dd></div>
            <div><dt className="text-xs uppercase tracking-wider text-mist">Total</dt><dd className="font-bold">{rupees(receipt.total)}</dd></div>
          </dl>
        </div>
        <div className="border-t-2 border-dashed border-line p-6 flex items-center justify-between">
          <span className="text-xs uppercase tracking-wider text-mist">Reference</span>
          <span className="font-mono text-2xl font-bold text-cyan">{receipt.reference}</span>
        </div>
      </article>
      <p className="text-sm text-mist">{receipt.disclaimer}</p>
      <Link to="/" className="inline-block rounded-md border border-line px-4 py-2 font-bold hover:border-cyan">Back to films</Link>
    </div>
  );
}
