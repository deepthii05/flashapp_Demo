import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, rupees } from "../services/api";
import type { AgentPlan, ReviewState } from "../types";

const EXAMPLES = [
  "Book two adjacent seats for the 7 PM show, with a total price below ₹800. Prefer the earliest available date.",
  "Book 2 adjacent seats for Neon Harbor at 7 PM, total below ₹800",
  "Book 4 seats for Ghost Circuit at 3 AM",
];

const STATUS_COPY: Record<AgentPlan["status"], { label: string; tone: string }> = {
  needs_clarification: { label: "Needs one more detail", tone: "border-caution/60 text-caution" },
  ready_for_review: { label: "Option found. Waiting for your confirmation.", tone: "border-cyan/60 text-cyan" },
  no_valid_option: { label: "No option meets every constraint", tone: "border-danger/60 text-danger" },
};

export default function Agent() {
  const navigate = useNavigate();
  const [text, setText] = useState(EXAMPLES[1]);
  const [plan, setPlan] = useState<AgentPlan | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    setBusy(true);
    setError(null);
    setPlan(null);
    try {
      setPlan(await api.plan(text));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  function reviewSelection() {
    if (!plan?.selected) return;
    const state: ReviewState = {
      showId: plan.selected.show_id,
      seats: plan.selected.seats,
      constraints: {
        max_total: plan.constraints.max_total,
        budget_strict: plan.constraints.budget_strict,
        adjacent_required: plan.constraints.adjacent,
        accessible_required: plan.constraints.accessible,
      },
    };
    navigate("/review", { state });
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_1fr]">
      <section className="space-y-5" aria-labelledby="agent-heading">
        <div>
          <h1 id="agent-heading" className="font-display text-4xl">AI booking</h1>
          <p className="mt-2 text-mist">
            Describe what you want in plain language. The agent reads your limits, searches the fictional schedule,
            and stops before anything is booked.
          </p>
        </div>

        <label htmlFor="request" className="block text-sm font-bold">Your request</label>
        <textarea
          id="request"
          rows={4}
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="w-full rounded-md border border-line bg-panel p-3 text-paper focus:border-cyan focus:outline-none"
        />
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={run}
            disabled={busy || text.trim().length < 3}
            className="rounded-md bg-violet px-5 py-3 font-bold text-night disabled:opacity-40"
          >
            {busy ? "Planning…" : "Run agent"}
          </button>
        </div>

        <div>
          <p className="mb-2 text-sm text-mist">Try an example</p>
          <ul className="space-y-2">
            {EXAMPLES.map((ex) => (
              <li key={ex}>
                <button type="button" onClick={() => setText(ex)} className="w-full rounded-md border border-line p-3 text-left text-sm text-mist hover:border-cyan hover:text-paper">
                  {ex}
                </button>
              </li>
            ))}
          </ul>
        </div>
        {error && <p role="alert" className="text-danger">{error}</p>}
      </section>

      <section aria-labelledby="result-heading" aria-live="polite" className="space-y-5">
        <h2 id="result-heading" className="font-display text-2xl">Agent result</h2>
        {!plan && !busy && <p className="text-mist">Run the agent to see its plan and activity log.</p>}

        {plan && (
          <>
            <p className={`rounded-md border px-4 py-3 font-bold ${STATUS_COPY[plan.status].tone}`}>
              {STATUS_COPY[plan.status].label}
            </p>

            {plan.status === "needs_clarification" && (
              <ul className="list-disc pl-5 space-y-1">
                {plan.questions?.map((q) => <li key={q}>{q}</li>)}
              </ul>
            )}

            {plan.status === "ready_for_review" && plan.selected && (
              <div className="space-y-4 rounded-md border border-line bg-panel p-5">
                <p className="font-bold">{plan.selected.movie_title}</p>
                <p className="text-sm text-mist">
                  {plan.selected.cinema_name} · {plan.selected.date} · {plan.selected.time}
                </p>
                <p>Seats {plan.selected.seats.join(", ")} · Total {rupees(plan.selected.total)}</p>
                <button type="button" onClick={reviewSelection} className="w-full rounded-md border border-cyan px-4 py-3 font-bold text-cyan hover:bg-cyan/10">
                  Review this booking
                </button>
                <p className="text-xs text-mist">You confirm on the next page. The agent does not book.</p>
              </div>
            )}

            {plan.status === "no_valid_option" && (
              <div className="space-y-3">
                {plan.reasons && Object.keys(plan.reasons).length > 0 && (
                  <p className="text-sm">Reasons: {Object.entries(plan.reasons).map(([k, v]) => `${k.replace(/_/g, " ")} (${v})`).join(", ")}</p>
                )}
                {plan.alternatives && plan.alternatives.length > 0 && (
                  <div>
                    <p className="text-sm font-bold">Nearby options for the same film</p>
                    <ul className="mt-2 list-disc pl-5 text-sm text-mist">
                      {plan.alternatives.map((a) => (
                        <li key={a.show_id}>{a.date} at {a.time}, {a.cinema_name}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            <div>
              <p className="text-sm font-bold">Constraints</p>
              <ul className="mt-2 flex flex-wrap gap-2 text-xs">
                {plan.constraints.hard_constraints.map((c) => (
                  <li key={c} className="rounded-full border border-line px-3 py-1">{c}</li>
                ))}
                {plan.constraints.soft_preferences.map((c) => (
                  <li key={c} className="rounded-full border border-dashed border-line px-3 py-1 text-mist">{c}</li>
                ))}
              </ul>
            </div>

            <div>
              <p className="text-sm font-bold">Activity log</p>
              <ol className="mt-2 space-y-2 border-l border-line pl-4 text-sm">
                {plan.log.map((s) => (
                  <li key={s.step}>
                    <span className="font-mono text-xs text-cyan">{s.action}</span>
                    <span className="block text-mist">{s.detail}</span>
                  </li>
                ))}
              </ol>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
