import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import SeatGrid from "../components/SeatGrid";
import { api, rupees } from "../services/api";
import type { ReviewState, SeatMap } from "../types";

export default function Seats() {
  const { showId = "" } = useParams();
  const navigate = useNavigate();
  const [map, setMap] = useState<SeatMap | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [count, setCount] = useState(2);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const MAX = 8;

  useEffect(() => {
    api.seats(showId).then(setMap).catch((e: Error) => setError(e.message));
  }, [showId]);

  const price = useMemo(() => {
    if (!map) return 0;
    return [...selected].reduce((sum, id) => sum + (map.seats.find((s) => s.id === id)?.price ?? 0), 0);
  }, [map, selected]);

  function toggle(id: string) {
    setError(null);
    if (!selected.has(id) && selected.size >= MAX) {
      setError(`You can select up to ${MAX} seats.`);
      return;
    }
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  /** Client-side convenience: find the first run of free adjacent seats. Server still validates. */
  function pickAdjacent() {
    if (!map) return;
    const free = new Set(map.seats.filter((s) => s.status === "available").map((s) => s.id));
    for (const row of [...map.rows].sort((a, b) => Math.abs(map.rows.indexOf(a) - 3.5) - Math.abs(map.rows.indexOf(b) - 3.5))) {
      const seats = map.seats.filter((s) => s.row === row).sort((a, b) => a.col - b.col);
      for (let i = 0; i + count <= seats.length; i++) {
        const window = seats.slice(i, i + count);
        if (window.every((s) => free.has(s.id)) && window.every((s, k) => k === 0 || s.col === window[k - 1].col + 1)) {
          setSelected(new Set(window.map((s) => s.id)));
          setError(null);
          return;
        }
      }
    }
    setError(`No ${count} adjacent seats are free for this showtime.`);
  }

  async function continueToReview() {
    if (!map || selected.size === 0) return;
    setBusy(true);
    setError(null);
    try {
      const seat_ids = [...selected].sort();
      const result = await api.validate({ show_id: showId, seat_ids });
      if (!result.valid) {
        setError(result.errors.map((e) => e.message).join(" "));
        return;
      }
      const state: ReviewState = { showId, seats: seat_ids };
      navigate("/review", { state });
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (error && !map) return <p role="alert" className="text-danger">{error}</p>;
  if (!map) return <p className="text-mist">Loading seats…</p>;

  const available = map.seats.filter((s) => s.status === "available").length;

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_340px]">
      <section aria-labelledby="seat-heading" className="space-y-6">
        <div>
          <Link to={`/movies/${map.movie_id}`} className="text-sm text-mist hover:text-paper">← {map.movie_title}</Link>
          <h1 id="seat-heading" className="mt-2 font-display text-4xl">Choose your seats</h1>
          <p className="text-mist">{map.cinema_name} · {map.date} · {map.time} · {available} of {map.seats.length} free</p>
        </div>

        <div className="flex flex-wrap items-center gap-3 rounded-md border border-line bg-panel p-4">
          <label htmlFor="count" className="text-sm">Seats together</label>
          <select
            id="count"
            value={count}
            onChange={(e) => setCount(Number(e.target.value))}
            className="rounded border border-line bg-night px-2 py-1"
          >
            {[1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
          <button type="button" onClick={pickAdjacent} className="rounded-md border border-cyan px-3 py-1.5 text-sm font-bold text-cyan hover:bg-cyan/10">
            Find adjacent seats
          </button>
          <button type="button" onClick={() => setSelected(new Set())} className="ml-auto text-sm text-mist hover:text-paper">
            Clear
          </button>
        </div>

        <SeatGrid rows={map.rows} seatsPerRow={map.seats_per_row} seats={map.seats} selected={selected} onToggle={toggle} disabled={busy} />
      </section>

      <aside aria-labelledby="summary" className="h-fit space-y-4 rounded-md border border-line bg-panel p-5 lg:sticky lg:top-24">
        <h2 id="summary" className="font-display text-2xl">Your selection</h2>
        <p className="text-sm text-mist">{selected.size === 0 ? "No seats selected." : [...selected].sort().join(", ")}</p>
        <dl className="flex justify-between text-lg font-bold">
          <dt>Total</dt>
          <dd aria-live="polite">{rupees(price)}</dd>
        </dl>
        {error && <p role="alert" className="text-sm text-danger">{error}</p>}
        <button
          type="button"
          disabled={selected.size === 0 || busy}
          onClick={continueToReview}
          className="w-full rounded-md bg-violet px-4 py-3 font-bold text-night disabled:opacity-40"
        >
          {busy ? "Checking seats…" : "Review booking"}
        </button>
        <p className="text-xs text-mist">Nothing is booked until you confirm on the next page.</p>
      </aside>
    </div>
  );
}
