export interface Movie {
  id: string;
  title: string;
  genre: string;
  duration_min: number;
  rating: string;
  synopsis: string;
  show_count: number;
}

export interface ShowSummary {
  show_id: string;
  movie_id: string;
  movie_title: string;
  cinema_id: string;
  cinema_name: string;
  date: string;
  time: string;
  available_seats: number;
  capacity: number;
  from_price: number;
}

export interface Seat {
  id: string;
  row: string;
  col: number;
  price: number;
  accessible: boolean;
  premium: boolean;
  status: "available" | "unavailable";
}

export interface SeatMap {
  show_id: string;
  movie_id: string;
  movie_title: string;
  cinema_id: string;
  cinema_name: string;
  date: string;
  time: string;
  rows: string[];
  seats_per_row: number;
  seats: Seat[];
}

export interface ApiErrorItem {
  code: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ApiErrorItem[];
  total: number;
  seat_prices: Record<string, number>;
}

export interface Constraints {
  max_total?: number | null;
  budget_strict?: boolean;
  adjacent_required?: boolean;
  accessible_required?: boolean;
}

export interface Receipt {
  reference: string;
  test_mode: boolean;
  disclaimer: string;
  seats: string[];
  total: number;
  show_id: string;
  movie_title: string;
  cinema_name: string;
  date: string;
  time: string;
}

export interface AgentLogStep {
  step: number;
  action: string;
  detail: string;
}

export interface AgentPlan {
  status: "needs_clarification" | "ready_for_review" | "no_valid_option";
  booking_created: boolean;
  requires_user_confirmation: boolean;
  questions?: string[];
  reasons?: Record<string, number>;
  alternatives?: { show_id: string; movie_title: string; cinema_name: string; date: string; time: string }[];
  near_misses?: { movie_title: string; cinema_name: string; date: string; time: string; seats: string[]; total: number; reason: string }[];
  selected?: {
    show_id: string;
    movie_title: string;
    cinema_name: string;
    date: string;
    time: string;
    seats: string[];
    total: number;
    seat_prices: Record<string, number>;
  };
  constraints: {
    hard_constraints: string[];
    soft_preferences: string[];
    seats: number | null;
    max_total: number | null;
    budget_strict: boolean;
    adjacent: boolean;
    accessible: boolean;
  };
  log: AgentLogStep[];
}

export interface ReviewState {
  showId: string;
  seats: string[];
  constraints?: Constraints;
}
