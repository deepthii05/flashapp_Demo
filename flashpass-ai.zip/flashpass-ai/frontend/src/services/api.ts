import type { AgentPlan, Constraints, Movie, Receipt, SeatMap, ShowSummary, ValidationResult, ApiErrorItem } from "../types";

export class ApiError extends Error {
  status: number;
  errors: ApiErrorItem[];
  constructor(status: number, message: string, errors: ApiErrorItem[] = []) {
    super(message);
    this.status = status;
    this.errors = errors;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    });
  } catch {
    throw new ApiError(0, "The FlashPass API is offline. Start the backend and try again.");
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = typeof body.detail === "string" ? body.detail : "Request failed.";
    throw new ApiError(res.status, detail, body.errors ?? []);
  }
  return body as T;
}

export const api = {
  health: () => request<{ status: string; mode: string; version: string }>("/api/health"),
  movies: () => request<Movie[]>("/api/movies"),
  shows: (params: { movie_id?: string; cinema_id?: string; date?: string } = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v) as [string, string][]);
    return request<ShowSummary[]>(`/api/shows?${q}`);
  },
  seats: (showId: string) => request<SeatMap>(`/api/seats?show_id=${encodeURIComponent(showId)}`),
  validate: (body: { show_id: string; seat_ids: string[] } & Constraints) =>
    request<ValidationResult>("/api/booking/validate", { method: "POST", body: JSON.stringify(body) }),
  confirm: (body: { show_id: string; seat_ids: string[]; user_confirmed: true } & Constraints) =>
    request<Receipt>("/api/booking/confirm", { method: "POST", body: JSON.stringify(body) }),
  booking: (ref: string) => request<Receipt>(`/api/booking/${encodeURIComponent(ref)}`),
  plan: (text: string) => request<AgentPlan>("/api/agent/plan", { method: "POST", body: JSON.stringify({ text }) }),
};

export const rupees = (n: number) => `₹${n.toLocaleString("en-IN")}`;
