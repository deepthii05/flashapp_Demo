import pytest

from app.catalog import CINEMAS_BY_ID, all_shows
from app.services.booking import ConfirmationRequired, BookingRejected, confirm, validate
from app.services.seats import available_seats, find_adjacent_block, pick_seats, seat_map, seeded_occupied


def _open_show():
    return next(s for s in all_shows() if s.cinema_id == "lumen-central")


def test_seat_map_capacity_is_configurable():
    assert len(seat_map("lumen-central")) == 8 * 12
    assert len(seat_map("orbit-westside")) == 8 * 8


def test_occupancy_is_deterministic():
    show = _open_show()
    assert [seeded_occupied(show.id, s.id) for s in seat_map("lumen-central")] == \
           [seeded_occupied(show.id, s.id) for s in seat_map("lumen-central")]


def test_adjacent_block_is_contiguous_in_one_row():
    cinema = CINEMAS_BY_ID["lumen-central"]
    available = {s.id for s in seat_map(cinema.id)}
    block = find_adjacent_block(cinema, available, 3, accessible_required=False)
    assert block is not None and len(block) == 3
    rows = {s[0] for s in block}
    assert len(rows) == 1
    cols = [int(s[1:]) for s in block]  # seat ids look like 'A10'
    assert cols == [cols[0], cols[0] + 1, cols[0] + 2]


def test_adjacent_required_fails_when_no_block():
    cinema = CINEMAS_BY_ID["lumen-central"]
    checkerboard = {s.id for s in seat_map(cinema.id) if s.col % 2 == 1}
    assert pick_seats(cinema, checkerboard, 2, adjacent_required=True, accessible_required=False) is None
    assert pick_seats(cinema, checkerboard, 2, adjacent_required=False, accessible_required=False) is not None


def test_validate_rejects_unknown_show_and_seat(db):
    assert validate(db, "nope", ["A1"]).errors[0]["code"] == "show_not_found"
    show = _open_show()
    codes = {e["code"] for e in validate(db, show.id, ["Z99"]).errors}
    assert "unknown_seat" in codes


def test_validate_flags_taken_seat(db):
    show = _open_show()
    free = sorted(available_seats(CINEMAS_BY_ID[show.cinema_id], show.id, set()))
    seat = free[0]
    confirm(db, show.id, [seat], user_confirmed=True)
    result = validate(db, show.id, [seat])
    assert not result.valid
    assert result.errors[0]["code"] == "seat_unavailable"


def test_budget_strict_vs_inclusive(db):
    show = _open_show()
    seat_ids = sorted(available_seats(CINEMAS_BY_ID[show.cinema_id], show.id, set()))[:1]
    total = validate(db, show.id, seat_ids).total
    assert validate(db, show.id, seat_ids, max_total=total).valid is True
    assert validate(db, show.id, seat_ids, max_total=total, budget_strict=True).valid is False


def test_confirmation_required_before_any_write(db):
    show = _open_show()
    seats = sorted(available_seats(CINEMAS_BY_ID[show.cinema_id], show.id, set()))[:2]
    with pytest.raises(ConfirmationRequired):
        confirm(db, show.id, seats, user_confirmed=False)
    assert db.count_bookings() == 0


def test_confirm_creates_booking_and_blocks_double_booking(db):
    show = _open_show()
    seats = sorted(available_seats(CINEMAS_BY_ID[show.cinema_id], show.id, set()))[:2]
    receipt = confirm(db, show.id, seats, user_confirmed=True)
    assert receipt["reference"].startswith("FP-")
    assert receipt["test_mode"] is True
    assert db.count_bookings() == 1
    with pytest.raises(BookingRejected):
        confirm(db, show.id, seats, user_confirmed=True)


def test_adjacent_validation(db):
    show = _open_show()
    result = validate(db, show.id, ["A1", "A3"], adjacent_required=True)
    assert "not_adjacent" in {e["code"] for e in result.errors}
