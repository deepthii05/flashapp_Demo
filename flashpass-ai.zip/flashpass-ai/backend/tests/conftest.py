import os
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("FLASHPASS_DB", ":memory:")

from app.main import create_app  # noqa: E402
from app.services.db import Database  # noqa: E402


@pytest.fixture()
def db():
    database = Database(":memory:")
    yield database
    database.close()


@pytest.fixture()
def client():
    app = create_app()
    os.environ["FLASHPASS_DB"] = ":memory:"
    with TestClient(app) as c:
        yield c
