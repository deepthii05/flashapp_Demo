from app.agent.parser import parse_budget, parse_request, parse_time


def test_time_pm_and_24h():
    assert parse_time("the 7 PM show") == "19:00"
    assert parse_time("at 7:30pm") == "19:30"
    assert parse_time("12 am") == "00:00"
    assert parse_time("12 pm") == "12:00"
    assert parse_time("show at 19:00") == "19:00"
    assert parse_time("no time here") is None


def test_budget_strictness():
    assert parse_budget("total price below ₹800") == (800, True)
    assert parse_budget("under Rs 1,200") == (1200, True)
    assert parse_budget("budget of ₹900") == (900, False)
    assert parse_budget("at most 600") == (600, False)
    assert parse_budget("nothing here") == (None, False)


def test_example_request_is_fully_structured_except_movie():
    spec = parse_request(
        "Book two adjacent seats for the 7 PM show, with a total price below ₹800. "
        "Prefer the earliest available date."
    )
    assert spec.seats == 2
    assert spec.adjacent is True
    assert spec.time == "19:00"
    assert spec.max_total == 800 and spec.budget_strict is True
    assert spec.date_preference == "earliest"
    assert spec.movie_id is None
    # Essential constraint missing -> clarification, not a guess.
    assert any("movie" in q.lower() for q in spec.clarification_questions)


def test_full_request_has_no_clarification():
    spec = parse_request("Book 3 seats for Neon Harbor at Lumen Central on 2 November at 19:00, under ₹1000")
    assert spec.clarification_questions == []
    assert spec.movie_id == "neon-harbor"
    assert spec.cinema_id == "lumen-central"
    assert spec.date == "2026-11-02"
    assert spec.seats == 3


def test_missing_seat_count_asks_question():
    spec = parse_request("Show me Ghost Circuit at 9:30 pm")
    assert spec.seats is None
    assert any("How many seats" in q for q in spec.clarification_questions)


def test_ambiguous_movie_asks_question():
    spec = parse_request("Book 2 seats for saffron or monsoon at 7 pm")
    assert spec.movie_id is None
    assert any("more than one movie" in q for q in spec.clarification_questions)


def test_for_n_people_is_seat_count_but_month_is_not():
    assert parse_request("Neon Harbor for 4 people at 7 pm").seats == 4
    assert parse_request("Neon Harbor on 2 Nov at 7 pm").seats is None
