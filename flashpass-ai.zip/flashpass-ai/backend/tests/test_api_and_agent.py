from app.agent.parser import parse_request
from app.agent.planner import plan
from app.services.db import Database


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200 and r.json()["mode"] == "test"


def test_catalogue_endpoints(client):
    movies = client.get("/api/movies").json()
    assert len(movies) == 4 and all(m["show_count"] > 0 for m in movies)
    assert len(client.get("/api/cinemas").json()) == 3


def test_shows_filter_and_404(client):
    shows = client.get("/api/shows", params={"movie_id": "neon-harbor"}).json()
    assert shows and all(s["movie_id"] == "neon-harbor" for s in shows)
    assert client.get("/api/shows", params={"movie_id": "nope"}).status_code == 404


def test_seats_endpoint(client):
    show = client.get("/api/shows").json()[0]["show_id"]
    body = client.get("/api/seats", params={"show_id": show}).json()
    assert len(body["seats"]) == len(body["rows"]) * body["seats_per_row"]
    assert {s["status"] for s in body["seats"]} <= {"available", "unavailable"}


def test_confirm_without_flag_is_refused(client):
    show = client.get("/api/shows").json()[0]["show_id"]
    r = client.post("/api/booking/confirm", json={"show_id": show, "seat_ids": ["A1"]})
    assert r.status_code == 400


def test_validate_then_confirm_flow(client):
    show = client.get("/api/shows").json()[0]["show_id"]
    seats = client.get("/api/seats", params={"show_id": show}).json()["seats"]
    free = [s["id"] for s in seats if s["status"] == "available"][:2]
    v = client.post("/api/booking/validate", json={"show_id": show, "seat_ids": free}).json()
    assert v["valid"] is True
    r = client.post("/api/booking/confirm", json={"show_id": show, "seat_ids": free, "user_confirmed": True})
    assert r.status_code == 201
    ref = r.json()["reference"]
    assert client.get(f"/api/booking/{ref}").json()["seats"] == sorted(free)


def test_invalid_seat_count_rejected_by_schema(client):
    show = client.get("/api/shows").json()[0]["show_id"]
    r = client.post("/api/booking/validate", json={"show_id": show, "seat_ids": []})
    assert r.status_code == 422


def test_planner_never_books_and_requests_confirmation(client, db):
    spec = parse_request("Book 2 adjacent seats for Neon Harbor at 7 PM, total below ₹800")
    result = plan(spec, db)
    assert result["booking_created"] is False
    if result["status"] == "ready_for_review":
        assert result["requires_user_confirmation"] is True
        assert result["hard_constraints_satisfied"] is True
        assert result["selected"]["total"] < 800
        assert len(result["selected"]["seats"]) == 2
    assert db.count_bookings() == 0


def test_impossible_time_explains_and_suggests(db):
    spec = parse_request("Book 2 seats for Neon Harbor at 3 AM")
    result = plan(spec, db)
    assert result["status"] == "no_valid_option"
    assert result["alternatives"], "should suggest alternatives for the same movie"
    assert db.count_bookings() == 0


def test_impossible_budget_never_books(db):
    spec = parse_request("Book 4 seats for Ghost Circuit at 7 PM under ₹100")
    result = plan(spec, db)
    assert result["status"] == "no_valid_option"
    assert db.count_bookings() == 0


def test_clarification_returned_for_missing_movie(db):
    result = plan(parse_request("Book two adjacent seats for the 7 PM show, below ₹800"), db)
    assert result["status"] == "needs_clarification"
    assert result["booking_created"] is False


def test_agent_run_is_honest_about_browser(client):
    r = client.post("/api/agent/run", json={"text": "Book 2 seats for Saffron Skies at 10:30"})
    assert r.json()["browser_executed"] is False


def test_agent_plan_endpoint_validates_input(client):
    assert client.post("/api/agent/plan", json={"text": "x"}).status_code == 422
