"""Seat map, pricing and adjacency logic.

Occupancy is seeded from the show id so the same show always starts with the same
unavailable seats. Bookings made through the API are stored separately in SQLite.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from functools import lru_cache

from ..catalog import Cinema

STANDARD_PRICE = 250  # INR, fictional
PREMIUM_EXTRA = 100  # INR added to premium rows
PREMIUM_ROW_COUNT = 3  # last N rows are premium
SEED_OCCUPANCY_RATE = 0.22


@dataclass(frozen=True)
class Seat:
    id: str
    row: str
    col: int
    accessible: bool
    premium: bool
    price: int


def _accessible(cinema: Cinema, row: str, col: int) -> bool:
    return row == cinema.rows[-1] and col in {1, 2, cinema.cols - 1, cinema.cols}


@lru_cache(maxsize=None)
def seat_map(cinema_id: str) -> tuple[Seat, ...]:
    from ..catalog import CINEMAS_BY_ID

    cinema = CINEMAS_BY_ID[cinema_id]
    premium_rows = set(cinema.rows[-PREMIUM_ROW_COUNT:])
    seats: list[Seat] = []
    for row in cinema.rows:
        for col in range(1, cinema.cols + 1):
            accessible = _accessible(cinema, row, col)
            premium = row in premium_rows and not accessible
            base = STANDARD_PRICE + (PREMIUM_EXTRA if premium else 0)
            seats.append(
                Seat(
                    id=f"{row}{col}",
                    row=row,
                    col=col,
                    accessible=accessible,
                    premium=premium,
                    price=round(base * cinema.price_multiplier),
                )
            )
    return tuple(seats)


@lru_cache(maxsize=None)
def seat_index(cinema_id: str) -> dict[str, Seat]:
    return {s.id: s for s in seat_map(cinema_id)}


def seeded_occupied(show_id: str, seat_id: str) -> bool:
    digest = hashlib.sha256(f"{show_id}|{seat_id}".encode()).digest()
    return digest[0] / 255 < SEED_OCCUPANCY_RATE


def available_seats(cinema: Cinema, show_id: str, taken: set[str]) -> set[str]:
    return {
        s.id
        for s in seat_map(cinema.id)
        if s.id not in taken and not seeded_occupied(show_id, s.id)
    }


def row_order(cinema: Cinema) -> list[str]:
    """Rows ordered from the centre outwards, so the best seats are offered first."""
    rows = list(cinema.rows)
    mid = (len(rows) - 1) / 2
    return sorted(rows, key=lambda r: (abs(rows.index(r) - mid), rows.index(r)))


def find_adjacent_block(
    cinema: Cinema, available: set[str], n: int, accessible_required: bool
) -> list[str] | None:
    index = seat_index(cinema.id)
    for row in row_order(cinema):
        cols = [s for s in seat_map(cinema.id) if s.row == row]
        for start in range(len(cols) - n + 1):
            window = cols[start : start + n]
            ids = [s.id for s in window]
            if not all(i in available for i in ids):
                continue
            if accessible_required and not all(index[i].accessible for i in ids):
                continue
            if any(window[k + 1].col != window[k].col + 1 for k in range(n - 1)):
                continue
            return ids
    return None


def pick_seats(
    cinema: Cinema,
    available: set[str],
    n: int,
    *,
    adjacent_required: bool,
    accessible_required: bool,
) -> list[str] | None:
    """Choose n seats. Adjacent blocks are preferred; non-adjacent is used only when allowed."""
    block = find_adjacent_block(cinema, available, n, accessible_required)
    if block:
        return block
    if adjacent_required:
        return None
    index = seat_index(cinema.id)
    pool = [
        s.id
        for row in row_order(cinema)
        for s in seat_map(cinema.id)
        if s.row == row and s.id in available and (not accessible_required or index[s.id].accessible)
    ]
    return pool[:n] if len(pool) >= n else None
