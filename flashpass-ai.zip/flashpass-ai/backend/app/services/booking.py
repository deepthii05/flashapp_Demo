"""Booking validation and the confirmation gate.

Boundary: validate() is read-only and may be called by planners. confirm() is the only
function that writes a booking, and it refuses to run unless the caller passes
user_confirmed=True. A planner's prediction is never treated as confirmation.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass, field

from ..catalog import CINEMAS_BY_ID, MOVIES_BY_ID, get_show
from .db import Database, SeatConflict
from .seats import seat_index, seeded_occupied

MAX_SEATS_PER_BOOKING = 8


class ConfirmationRequired(Exception):
    pass


class BookingRejected(Exception):
    def __init__(self, errors: list[dict]) -> None:
        super().__init__("; ".join(e["message"] for e in errors))
        self.errors = errors


@dataclass
class ValidationResult:
    valid: bool
    errors: list[dict] = field(default_factory=list)
    total: int = 0
    seat_prices: dict[str, int] = field(default_factory=dict)
    show_id: str | None = None


def _err(code: str, message: str) -> dict:
    return {"code": code, "message": message}


def _is_adjacent(seat_ids: list[str], index: dict) -> bool:
    seats = sorted((index[s] for s in seat_ids), key=lambda s: (s.row, s.col))
    return all(
        a.row == b.row and b.col == a.col + 1 for a, b in zip(seats, seats[1:])
    )


def validate(
    db: Database,
    show_id: str,
    seat_ids: list[str],
    *,
    max_total: int | None = None,
    budget_strict: bool = False,
    accessible_required: bool = False,
    adjacent_required: bool = False,
) -> ValidationResult:
    show = get_show(show_id)
    if show is None:
        return ValidationResult(False, [_err("show_not_found", f"Unknown show '{show_id}'.")])

    errors: list[dict] = []
    if not seat_ids:
        errors.append(_err("no_seats", "Select at least one seat."))
    if len(seat_ids) > MAX_SEATS_PER_BOOKING:
        errors.append(_err("too_many_seats", f"You can book at most {MAX_SEATS_PER_BOOKING} seats."))
    if len(set(seat_ids)) != len(seat_ids):
        errors.append(_err("duplicate_seat", "The same seat was selected twice."))

    cinema = CINEMAS_BY_ID[show.cinema_id]
    index = seat_index(cinema.id)
    unknown = [s for s in seat_ids if s not in index]
    for s in unknown:
        errors.append(_err("unknown_seat", f"Seat {s} does not exist in this cinema."))

    known = [s for s in seat_ids if s in index]
    taken = db.taken_seats(show_id)
    for s in known:
        if s in taken or seeded_occupied(show_id, s):
            errors.append(_err("seat_unavailable", f"Seat {s} is no longer available."))
        if accessible_required and not index[s].accessible:
            errors.append(_err("accessible_required", f"Seat {s} is not an accessible seat."))

    if adjacent_required and len(known) > 1 and not _is_adjacent(known, index):
        errors.append(_err("not_adjacent", "The selected seats are not adjacent."))

    total = sum(index[s].price for s in known)
    if max_total is not None and not unknown:
        over = total >= max_total if budget_strict else total > max_total
        if over:
            comparator = "below" if budget_strict else "within"
            errors.append(
                _err("over_budget", f"Total ₹{total} is not {comparator} the ₹{max_total} limit.")
            )

    return ValidationResult(
        valid=not errors,
        errors=errors,
        total=total,
        seat_prices={s: index[s].price for s in known},
        show_id=show_id,
    )


def describe_show(show_id: str) -> dict:
    show = get_show(show_id)
    assert show is not None
    movie = MOVIES_BY_ID[show.movie_id]
    cinema = CINEMAS_BY_ID[show.cinema_id]
    return {
        "show_id": show.id,
        "movie_id": movie.id,
        "movie_title": movie.title,
        "cinema_id": cinema.id,
        "cinema_name": cinema.name,
        "date": show.date,
        "time": show.time,
    }


def confirm(
    db: Database,
    show_id: str,
    seat_ids: list[str],
    *,
    user_confirmed: bool,
    max_total: int | None = None,
    budget_strict: bool = False,
    accessible_required: bool = False,
    adjacent_required: bool = False,
) -> dict:
    if user_confirmed is not True:
        raise ConfirmationRequired("Explicit user confirmation is required before a booking is created.")

    result = validate(
        db,
        show_id,
        seat_ids,
        max_total=max_total,
        budget_strict=budget_strict,
        accessible_required=accessible_required,
        adjacent_required=adjacent_required,
    )
    if not result.valid:
        raise BookingRejected(result.errors)

    reference = "FP-" + secrets.token_hex(3).upper()
    try:
        db.insert_booking(
            reference,
            show_id,
            [(s, result.seat_prices[s]) for s in seat_ids],
        )
    except SeatConflict:
        raise BookingRejected([_err("seat_unavailable", "A selected seat was booked moments ago.")])

    return {
        "reference": reference,
        "test_mode": True,
        "disclaimer": "FlashPass AI test-mode booking. Fictional event. No payment was collected.",
        "seats": sorted(seat_ids),
        "total": result.total,
        **describe_show(show_id),
    }
