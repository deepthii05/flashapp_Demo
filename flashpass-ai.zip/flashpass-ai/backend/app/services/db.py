"""SQLite persistence. Stores fictional test-mode bookings only."""

from __future__ import annotations

import sqlite3
import threading
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS bookings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    reference   TEXT    NOT NULL,
    show_id     TEXT    NOT NULL,
    seat_id     TEXT    NOT NULL,
    price       INTEGER NOT NULL,
    created_at  TEXT    NOT NULL,
    UNIQUE (show_id, seat_id)
);
CREATE INDEX IF NOT EXISTS idx_bookings_reference ON bookings (reference);
"""


class SeatConflict(Exception):
    """Raised when a seat was booked between validation and commit."""


class Database:
    def __init__(self, path: str = ":memory:") -> None:
        self.path = path
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)

    def taken_seats(self, show_id: str) -> set[str]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT seat_id FROM bookings WHERE show_id = ?", (show_id,)
            ).fetchall()
        return {r["seat_id"] for r in rows}

    def insert_booking(self, reference: str, show_id: str, seats: list[tuple[str, int]]) -> None:
        created = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with self._lock:
            try:
                with self._conn:  # single transaction: all seats or none
                    self._conn.executemany(
                        "INSERT INTO bookings (reference, show_id, seat_id, price, created_at) "
                        "VALUES (?, ?, ?, ?, ?)",
                        [(reference, show_id, seat_id, price, created) for seat_id, price in seats],
                    )
            except sqlite3.IntegrityError as exc:
                raise SeatConflict(str(exc)) from exc

    def get_booking(self, reference: str) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT reference, show_id, seat_id, price, created_at FROM bookings "
                "WHERE reference = ? ORDER BY seat_id",
                (reference,),
            ).fetchall()
        return [dict(r) for r in rows]

    def count_bookings(self) -> int:
        with self._lock:
            return self._conn.execute("SELECT COUNT(DISTINCT reference) FROM bookings").fetchone()[0]

    def close(self) -> None:
        self._conn.close()
