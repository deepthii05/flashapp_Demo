"""Fictional catalogue: movies, cinemas, dates and showtimes.

Nothing here refers to real films, venues or ticketing services.
The schedule is generated deterministically so tests and benchmarks are reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

TODAY = "2026-10-31"
BASE_DATES: tuple[str, ...] = ("2026-11-01", "2026-11-02", "2026-11-03")
SHOW_TIMES: tuple[str, ...] = ("10:30", "13:45", "19:00", "21:30")


@dataclass(frozen=True)
class Movie:
    id: str
    title: str
    genre: str
    duration_min: int
    rating: str
    synopsis: str
    aliases: tuple[str, ...]


@dataclass(frozen=True)
class Cinema:
    id: str
    name: str
    aliases: tuple[str, ...]
    rows: str  # row labels, front to back
    cols: int  # seats per row (configurable capacity)
    price_multiplier: float


@dataclass(frozen=True)
class Show:
    id: str
    movie_id: str
    cinema_id: str
    date: str
    time: str


MOVIES: tuple[Movie, ...] = (
    Movie(
        "neon-harbor", "Neon Harbor", "Sci-Fi", 128, "UA13+",
        "A harbour city runs on rented memories, until a courier finds one that is not hers.",
        ("neon harbor", "neon harbour"),
    ),
    Movie(
        "monsoon-train", "The Last Monsoon Train", "Drama", 112, "U",
        "Three strangers share a night train that is delayed by the rains for the last time.",
        ("monsoon",),
    ),
    Movie(
        "ghost-circuit", "Ghost Circuit", "Thriller", 104, "A",
        "A retired racing engineer hears messages from a circuit that was closed years ago.",
        ("ghost circuit", "ghost"),
    ),
    Movie(
        "saffron-skies", "Saffron Skies", "Comedy", 98, "U",
        "A failed kite-maker and her grandmother enter a town-wide festival competition.",
        ("saffron",),
    ),
)

CINEMAS: tuple[Cinema, ...] = (
    Cinema("lumen-central", "Lumen Cinemas Central", ("lumen", "central"), "ABCDEFGH", 12, 1.0),
    Cinema("halcyon-riverside", "Halcyon Multiplex Riverside", ("halcyon", "riverside"), "ABCDEFGH", 10, 1.1),
    Cinema("orbit-westside", "Orbit Screens Westside", ("orbit", "westside"), "ABCDEFGH", 8, 0.9),
)

MOVIES_BY_ID = {m.id: m for m in MOVIES}
CINEMAS_BY_ID = {c.id: c for c in CINEMAS}


def _show_id(movie_id: str, cinema_id: str, date: str, time: str) -> str:
    return f"{movie_id}|{cinema_id}|{date}|{time}"


@lru_cache(maxsize=1)
def all_shows() -> tuple[Show, ...]:
    """Deterministic schedule: roughly two thirds of the movie/cinema/date/time grid is scheduled."""
    shows: list[Show] = []
    for mi, movie in enumerate(MOVIES):
        for ci, cinema in enumerate(CINEMAS):
            for di, date in enumerate(BASE_DATES):
                for ti, time in enumerate(SHOW_TIMES):
                    if (mi + 2 * ci + di + ti) % 3 == 0:
                        continue
                    shows.append(Show(_show_id(movie.id, cinema.id, date, time), movie.id, cinema.id, date, time))
    return tuple(shows)


@lru_cache(maxsize=1)
def shows_by_id() -> dict[str, Show]:
    return {s.id: s for s in all_shows()}


def get_show(show_id: str) -> Show | None:
    return shows_by_id().get(show_id)
