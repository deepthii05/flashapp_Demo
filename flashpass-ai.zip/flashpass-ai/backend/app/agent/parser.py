"""Rule-based parser: natural-language request -> TaskSpec.

This is the deterministic mode that needs no API key. An optional LLM parser can
replace it later, but must return the same TaskSpec shape and be validated the same way.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from datetime import date, timedelta

from ..catalog import BASE_DATES, CINEMAS, MOVIES, SHOW_TIMES, TODAY

NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8,
}
MONTHS = {"nov": 11, "november": 11, "oct": 10, "october": 10, "dec": 12, "december": 12}


@dataclass
class TaskSpec:
    raw_text: str
    movie_id: str | None = None
    cinema_id: str | None = None
    date: str | None = None
    date_preference: str | None = None  # "earliest" when the user asks for the first available
    time: str | None = None  # 24-hour HH:MM
    seats: int | None = None
    adjacent: bool = False
    accessible: bool = False
    max_total: int | None = None
    budget_strict: bool = False  # True for "below"/"under": total must be strictly less
    hard_constraints: list[str] = field(default_factory=list)
    soft_preferences: list[str] = field(default_factory=list)
    clarification_questions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def _to_int(token: str) -> int | None:
    token = token.lower()
    if token.isdigit():
        return int(token)
    return NUMBER_WORDS.get(token)


def parse_time(text: str) -> str | None:
    m = re.search(r"\b(\d{1,2})(?::([0-5]\d))?\s*(a\.?m\.?|p\.?m\.?)(?![a-z])", text, re.I)
    if m:
        hour = int(m.group(1))
        minute = int(m.group(2) or 0)
        meridiem = m.group(3).lower().replace(".", "")
        if not 1 <= hour <= 12:
            return None
        if meridiem == "pm" and hour != 12:
            hour += 12
        if meridiem == "am" and hour == 12:
            hour = 0
        return f"{hour:02d}:{minute:02d}"
    m = re.search(r"\b([01]?\d|2[0-3]):([0-5]\d)\b", text)
    if m:
        return f"{int(m.group(1)):02d}:{m.group(2)}"
    return None


BUDGET_RE = re.compile(
    r"(below|under|less than|lower than|max(?:imum)?|at most|up to|within|no more than|budget(?: of)?)"
    r"\s*(?:is\s*)?(?:₹|rs\.?\s*|inr\s*)?(\d[\d,]*)",
    re.I,
)
SEAT_RE = re.compile(
    r"\b(\d+|one|two|three|four|five|six|seven|eight)\s+"
    r"(?:adjacent\s+|consecutive\s+|accessible\s+|wheelchair\s+)?"
    r"(?:seats?|tickets?|people|persons?|adults?)\b",
    re.I,
)
FOR_N_RE = re.compile(
    r"\bfor\s+(\d+|one|two|three|four|five|six|seven|eight)\b"
    r"(?!\s*(?:am|pm|:|nov|november|oct|october|dec|december))",
    re.I,
)


def parse_seats(text: str) -> int | None:
    m = SEAT_RE.search(text) or FOR_N_RE.search(text)
    return _to_int(m.group(1)) if m else None


def parse_budget(text: str) -> tuple[int | None, bool]:
    m = BUDGET_RE.search(text)
    if not m:
        return None, False
    strict = m.group(1).lower() in {"below", "under", "less than", "lower than"}
    return int(m.group(2).replace(",", "")), strict


def parse_date(text: str) -> str | None:
    lower = text.lower()
    m = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", text)
    if m:
        return m.group(1)
    m = re.search(r"\b(\d{1,2})\s+(nov|november|oct|october|dec|december)\b", lower)
    if m:
        return f"2026-{MONTHS[m.group(2)]:02d}-{int(m.group(1)):02d}"
    m = re.search(r"\b(nov|november|oct|october|dec|december)\s+(\d{1,2})\b", lower)
    if m:
        return f"2026-{MONTHS[m.group(1)]:02d}-{int(m.group(2)):02d}"
    if "tomorrow" in lower:
        return (date.fromisoformat(TODAY) + timedelta(days=1)).isoformat()
    return None


def _find_movie_ids(text: str) -> list[str]:
    lower = text.lower()
    found = []
    for movie in MOVIES:
        names = (movie.title.lower(),) + movie.aliases
        if any(n in lower for n in names):
            found.append(movie.id)
    return found


def _find_cinema_id(text: str) -> str | None:
    lower = text.lower()
    for cinema in CINEMAS:
        if any(re.search(rf"\b{re.escape(a)}\b", lower) for a in cinema.aliases):
            return cinema.id
    return None


def parse_request(text: str) -> TaskSpec:
    text = text.strip()
    spec = TaskSpec(raw_text=text)

    spec.seats = parse_seats(text)
    spec.time = parse_time(text)
    spec.date = parse_date(text)
    spec.max_total, spec.budget_strict = parse_budget(text)
    spec.cinema_id = _find_cinema_id(text)
    spec.accessible = bool(re.search(r"wheelchair|accessib|disabilit", text, re.I))
    spec.adjacent = bool(re.search(r"adjacent|next to each other|side by side|together|consecutive", text, re.I))
    if re.search(r"earliest|first available|soonest|as early as possible", text, re.I):
        spec.date_preference = "earliest"

    movie_ids = _find_movie_ids(text)
    if len(movie_ids) == 1:
        spec.movie_id = movie_ids[0]

    if spec.seats is None:
        spec.clarification_questions.append("How many seats should I book?")
    if not movie_ids:
        spec.clarification_questions.append("Which movie should I book? Tell me the title.")
    elif len(movie_ids) > 1:
        spec.clarification_questions.append(
            "That matches more than one movie. Which one do you want?"
        )

    if spec.seats:
        spec.hard_constraints.append(f"seats = {spec.seats}")
    if spec.adjacent:
        spec.hard_constraints.append("seats must be adjacent")
    if spec.accessible:
        spec.hard_constraints.append("accessible seats only")
    if spec.time:
        spec.hard_constraints.append(f"showtime = {spec.time}")
    if spec.date:
        spec.hard_constraints.append(f"date = {spec.date}")
    if spec.max_total is not None:
        op = "<" if spec.budget_strict else "<="
        spec.hard_constraints.append(f"total {op} ₹{spec.max_total}")
    if spec.cinema_id:
        spec.hard_constraints.append(f"cinema = {spec.cinema_id}")
    if spec.date_preference == "earliest":
        spec.soft_preferences.append("earliest available date")

    if spec.time and spec.time not in SHOW_TIMES:
        spec.soft_preferences.append(f"requested time {spec.time} is not in the standard schedule")
    if spec.date and spec.date not in BASE_DATES:
        spec.soft_preferences.append(f"requested date {spec.date} is outside the schedule")
    return spec
