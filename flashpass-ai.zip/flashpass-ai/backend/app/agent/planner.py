"""Planner: TaskSpec -> candidate search -> selected option or explained failure.

The planner never creates a booking. Its output always carries
booking_created=False and requires_user_confirmation=True when a plan is ready.
"""

from __future__ import annotations

from collections import Counter

from ..catalog import CINEMAS_BY_ID, MOVIES_BY_ID, Show, all_shows
from ..services.booking import describe_show, validate
from ..services.db import Database
from ..services.seats import available_seats, pick_seats
from .parser import TaskSpec


class Log:
    def __init__(self) -> None:
        self.steps: list[dict] = []

    def add(self, action: str, detail: str) -> None:
        self.steps.append({"step": len(self.steps) + 1, "action": action, "detail": detail})


def _matching_shows(spec: TaskSpec) -> list[Show]:
    out = []
    for show in all_shows():
        if spec.movie_id and show.movie_id != spec.movie_id:
            continue
        if spec.cinema_id and show.cinema_id != spec.cinema_id:
            continue
        if spec.date and show.date != spec.date:
            continue
        if spec.time and show.time != spec.time:
            continue
        out.append(show)
    return sorted(out, key=lambda s: (s.date, s.time, s.cinema_id))


def _alternatives(spec: TaskSpec, limit: int = 3) -> list[dict]:
    """Nearby shows for the same movie when the exact request cannot be met."""
    relaxed = TaskSpec(raw_text=spec.raw_text, movie_id=spec.movie_id)
    shows = _matching_shows(relaxed)
    if spec.date:
        shows = [s for s in shows if s.date == spec.date] or shows
    return [
        {"show_id": s.id, "date": s.date, "time": s.time, "cinema_id": s.cinema_id,
         "movie_title": MOVIES_BY_ID[s.movie_id].title,
         "cinema_name": CINEMAS_BY_ID[s.cinema_id].name}
        for s in shows[:limit]
    ]


def plan(spec: TaskSpec, db: Database) -> dict:
    log = Log()
    log.add("parse", f"Parsed {len(spec.hard_constraints)} hard constraint(s).")
    base = {
        "constraints": spec.to_dict(),
        "booking_created": False,
        "requires_user_confirmation": False,
    }

    if spec.clarification_questions:
        log.add("clarify", "Essential information is missing, so no search was run.")
        return {**base, "status": "needs_clarification",
                "questions": spec.clarification_questions, "log": log.steps}

    candidates = _matching_shows(spec)
    log.add("search", f"Found {len(candidates)} show(s) matching movie, cinema, date and time.")
    if not candidates:
        log.add("stop", "No show satisfies the hard constraints. Suggesting alternatives.")
        return {**base, "status": "no_valid_option",
                "reasons": {"no_matching_show": 1}, "alternatives": _alternatives(spec),
                "log": log.steps}

    reasons: Counter = Counter()
    rejected: list[dict] = []
    for show in candidates:
        cinema = CINEMAS_BY_ID[show.cinema_id]
        taken = db.taken_seats(show.id)
        free = available_seats(cinema, show.id, taken)
        log.add("check_seats", f"{show.date} {show.time} at {cinema.name}: {len(free)} seat(s) free.")

        chosen = pick_seats(
            cinema, free, spec.seats,
            adjacent_required=spec.adjacent, accessible_required=spec.accessible,
        )
        if not chosen:
            reason = "no_adjacent_block" if spec.adjacent else "not_enough_seats"
            reasons[reason] += 1
            continue

        check = validate(
            db, show.id, chosen,
            max_total=spec.max_total, budget_strict=spec.budget_strict,
            accessible_required=spec.accessible, adjacent_required=spec.adjacent,
        )
        if not check.valid:
            code = check.errors[0]["code"]
            reasons[code] += 1
            rejected.append({**describe_show(show.id), "seats": chosen, "total": check.total,
                             "reason": check.errors[0]["message"]})
            log.add("reject", check.errors[0]["message"])
            continue

        log.add("select", f"Selected {', '.join(chosen)} for {show.date} {show.time}.")
        log.add("verify", "All hard constraints re-checked against current seat state.")
        log.add("stop", "Waiting for explicit user confirmation. No booking was created.")
        return {
            **base,
            "status": "ready_for_review",
            "requires_user_confirmation": True,
            "hard_constraints_satisfied": True,
            "selected": {**describe_show(show.id), "seats": chosen,
                         "total": check.total, "seat_prices": check.seat_prices},
            "log": log.steps,
        }

    log.add("stop", "No valid option found. Nothing was booked.")
    return {
        **base,
        "status": "no_valid_option",
        "reasons": dict(reasons),
        "near_misses": rejected[:3],
        "alternatives": _alternatives(spec),
        "log": log.steps,
    }
