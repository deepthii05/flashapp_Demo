"""FlashPass AI backend. Test-mode only: fictional catalogue, no payments."""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .agent.parser import parse_request
from .agent.planner import plan as make_plan
from .api.schemas import AgentRequest, BookingCheck, BookingConfirm
from .catalog import CINEMAS, CINEMAS_BY_ID, MOVIES, MOVIES_BY_ID, SHOW_TIMES, all_shows, get_show
from .services.booking import BookingRejected, ConfirmationRequired, confirm, describe_show, validate
from .services.db import Database
from .services.seats import available_seats, seat_map

VERSION = "0.1.0"
DEFAULT_DB = Path(__file__).resolve().parent.parent / "data" / "flashpass.db"


@asynccontextmanager
async def lifespan(app: FastAPI):
    db_path = os.environ.get("FLASHPASS_DB", str(DEFAULT_DB))
    if db_path != ":memory:":
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    app.state.db = Database(db_path)
    yield
    app.state.db.close()


def create_app() -> FastAPI:
    app = FastAPI(title="FlashPass AI API", version=VERSION, lifespan=lifespan)
    origins = os.environ.get("FLASHPASS_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[o.strip() for o in origins.split(",") if o.strip()],
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )

    @app.exception_handler(ValueError)
    async def _value_error(request: Request, exc: ValueError):
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    def db() -> Database:
        return app.state.db

    @app.get("/api/health")
    def health():
        return {"status": "ok", "version": VERSION, "mode": "test", "bookings": db().count_bookings()}

    @app.get("/api/movies")
    def movies():
        shows = all_shows()
        return [
            {
                "id": m.id, "title": m.title, "genre": m.genre, "duration_min": m.duration_min,
                "rating": m.rating, "synopsis": m.synopsis,
                "show_count": sum(1 for s in shows if s.movie_id == m.id),
            }
            for m in MOVIES
        ]

    @app.get("/api/cinemas")
    def cinemas():
        return [
            {"id": c.id, "name": c.name, "rows": len(c.rows), "seats_per_row": c.cols,
             "capacity": len(c.rows) * c.cols}
            for c in CINEMAS
        ]

    @app.get("/api/shows")
    def shows(
        movie_id: str | None = None,
        cinema_id: str | None = None,
        date: str | None = None,
    ):
        if movie_id and movie_id not in MOVIES_BY_ID:
            raise HTTPException(404, "Unknown movie.")
        if cinema_id and cinema_id not in CINEMAS_BY_ID:
            raise HTTPException(404, "Unknown cinema.")
        out = []
        for s in all_shows():
            if movie_id and s.movie_id != movie_id:
                continue
            if cinema_id and s.cinema_id != cinema_id:
                continue
            if date and s.date != date:
                continue
            cinema = CINEMAS_BY_ID[s.cinema_id]
            free = available_seats(cinema, s.id, db().taken_seats(s.id))
            out.append({**describe_show(s.id), "available_seats": len(free),
                        "capacity": len(cinema.rows) * cinema.cols,
                        "from_price": min(seat.price for seat in seat_map(cinema.id))})
        return out

    @app.get("/api/seats")
    def seats(show_id: str = Query(min_length=1)):
        show = get_show(show_id)
        if show is None:
            raise HTTPException(404, "Unknown show.")
        cinema = CINEMAS_BY_ID[show.cinema_id]
        free = available_seats(cinema, show.id, db().taken_seats(show.id))
        return {
            **describe_show(show.id),
            "rows": list(cinema.rows),
            "seats_per_row": cinema.cols,
            "seats": [
                {"id": s.id, "row": s.row, "col": s.col, "price": s.price,
                 "accessible": s.accessible, "premium": s.premium,
                 "status": "available" if s.id in free else "unavailable"}
                for s in seat_map(cinema.id)
            ],
        }

    @app.post("/api/booking/validate")
    def booking_validate(body: BookingCheck):
        result = validate(
            db(), body.show_id, body.seat_ids,
            max_total=body.max_total, budget_strict=body.budget_strict,
            accessible_required=body.accessible_required, adjacent_required=body.adjacent_required,
        )
        return {"valid": result.valid, "errors": result.errors, "total": result.total,
                "seat_prices": result.seat_prices}

    @app.post("/api/booking/confirm", status_code=201)
    def booking_confirm(body: BookingConfirm):
        try:
            return confirm(
                db(), body.show_id, body.seat_ids, user_confirmed=body.user_confirmed,
                max_total=body.max_total, budget_strict=body.budget_strict,
                accessible_required=body.accessible_required, adjacent_required=body.adjacent_required,
            )
        except ConfirmationRequired as exc:
            raise HTTPException(400, str(exc))
        except BookingRejected as exc:
            return JSONResponse(status_code=409, content={"detail": "Booking rejected.", "errors": exc.errors})

    @app.get("/api/booking/{reference}")
    def booking_lookup(reference: str):
        rows = db().get_booking(reference)
        if not rows:
            raise HTTPException(404, "No booking with that reference.")
        return {"reference": reference, "seats": [r["seat_id"] for r in rows],
                "total": sum(r["price"] for r in rows), "show_id": rows[0]["show_id"],
                **describe_show(rows[0]["show_id"]), "test_mode": True}

    @app.post("/api/agent/plan")
    def agent_plan(body: AgentRequest):
        spec = parse_request(body.text)
        return make_plan(spec, db())

    @app.post("/api/agent/run")
    def agent_run(body: AgentRequest):
        # Phase 1: planner-only. Browser execution (Playwright) is not built yet, and this
        # endpoint says so explicitly rather than pretending to drive a browser.
        spec = parse_request(body.text)
        result = make_plan(spec, db())
        return {**result, "mode": "rule_planner", "browser_executed": False,
                "note": "Browser execution is not implemented yet. Plan only."}

    return app


app = create_app()
