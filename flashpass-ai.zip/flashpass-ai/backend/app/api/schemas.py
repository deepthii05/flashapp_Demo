from __future__ import annotations

from pydantic import BaseModel, Field


class BookingCheck(BaseModel):
    show_id: str = Field(min_length=1, max_length=200)
    seat_ids: list[str] = Field(min_length=1, max_length=8)
    max_total: int | None = Field(default=None, ge=0, le=100000)
    budget_strict: bool = False
    accessible_required: bool = False
    adjacent_required: bool = False


class BookingConfirm(BookingCheck):
    # Must be exactly true. Anything else is refused with a 400.
    user_confirmed: bool = False


class AgentRequest(BaseModel):
    text: str = Field(min_length=3, max_length=500)
