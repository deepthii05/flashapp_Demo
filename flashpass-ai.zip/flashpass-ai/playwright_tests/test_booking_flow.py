import json
import re
import urllib.request


def _bookings(api_url: str) -> int:
    with urllib.request.urlopen(f"{api_url}/api/health", timeout=5) as r:
        return json.load(r)["bookings"]


def test_home_lists_films_and_filters(page, base_url):
    page.goto(base_url + "/")
    page.get_by_role("heading", name="Your booking, intelligently handled.").wait_for()
    assert page.get_by_role("link", name="Try AI Booking").is_visible()
    page.get_by_label("Search films").fill("ghost")
    page.get_by_role("link", name=re.compile("Ghost Circuit")).wait_for()
    assert page.get_by_role("link", name=re.compile("Neon Harbor")).count() == 0


def test_agent_stops_before_booking_and_user_confirms(page, base_url, api_url):
    before = _bookings(api_url)
    page.goto(base_url + "/agent")
    page.get_by_label("Your request").fill("Book 2 adjacent seats for Neon Harbor at 7 PM, total below ₹800")
    page.get_by_role("button", name="Run agent").click()
    page.get_by_role("button", name="Review this booking").wait_for()
    # Running the agent must not create a booking.
    assert _bookings(api_url) == before

    page.get_by_role("button", name="Review this booking").click()
    page.get_by_role("heading", name="Review your booking").wait_for()
    confirm = page.get_by_role("button", name="Confirm test booking")
    assert confirm.is_disabled(), "confirm must stay disabled until the user ticks the box"
    page.get_by_label("I have checked these details").check()
    assert confirm.is_enabled()
    confirm.click()

    page.get_by_role("heading", name="Booked").wait_for()
    reference = page.locator("span.font-mono").inner_text()
    assert reference.startswith("FP-")
    assert _bookings(api_url) == before + 1


def test_agent_asks_for_missing_movie(page, base_url, api_url):
    before = _bookings(api_url)
    page.goto(base_url + "/agent")
    page.get_by_role("button", name=re.compile("Book two adjacent seats for the 7 PM")).click()
    page.get_by_role("button", name="Run agent").click()
    page.get_by_text("Which movie should I book?").wait_for()
    assert _bookings(api_url) == before


def test_manual_flow_selects_seats_and_shows_live_total(page, base_url):
    page.goto(base_url + "/movies/saffron-skies")
    page.locator("a[aria-label*='seats left']").first.click()
    page.get_by_role("heading", name="Choose your seats").wait_for()

    free = page.locator("button[aria-label*='Seat'][aria-label*='rupees']:not([disabled])")
    free.nth(0).click()
    free.nth(1).click()
    total = page.locator("[aria-live='polite']").filter(has_text="₹").first.inner_text()
    assert total.startswith("₹") and total != "₹0"
    assert page.get_by_role("button", name="Review booking").is_enabled()


def test_unavailable_seats_cannot_be_selected(page, base_url):
    page.goto(base_url + "/movies/ghost-circuit")
    page.locator("a[aria-label*='seats left']").first.click()
    page.get_by_role("heading", name="Choose your seats").wait_for()
    disabled = page.locator("button[aria-label*='unavailable']")
    assert disabled.count() > 0
    assert disabled.first.is_disabled()


def test_mobile_layout_has_no_horizontal_overflow(browser, base_url):
    ctx = browser.new_context(viewport={"width": 390, "height": 844})
    pg = ctx.new_page()
    pg.goto(base_url + "/")
    pg.get_by_role("heading", name="Your booking, intelligently handled.").wait_for()
    overflow = pg.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth")
    ctx.close()
    assert overflow is False
