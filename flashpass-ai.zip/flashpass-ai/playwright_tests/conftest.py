"""Browser tests run against a live backend (port 8000) and frontend (port 5173).

Start both first, or use scripts/run_smoke.sh which starts them for you.
"""
import os

import pytest
from playwright.sync_api import sync_playwright

BASE_URL = os.environ.get("FLASHPASS_UI_URL", "http://127.0.0.1:5173")
API_URL = os.environ.get("FLASHPASS_API_URL", "http://127.0.0.1:8000")


@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as p:
        b = p.chromium.launch()
        yield b
        b.close()


@pytest.fixture()
def page(browser):
    ctx = browser.new_context(viewport={"width": 1280, "height": 900})
    pg = ctx.new_page()
    pg.set_default_timeout(10_000)
    yield pg
    ctx.close()


@pytest.fixture()
def base_url():
    return BASE_URL


@pytest.fixture()
def api_url():
    return API_URL
